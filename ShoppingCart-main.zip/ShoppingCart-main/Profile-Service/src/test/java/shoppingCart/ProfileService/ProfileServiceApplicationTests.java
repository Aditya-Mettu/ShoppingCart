package shoppingCart.ProfileService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileServiceApplicationTests {

	

}
